<?php
	require_once 'config.php';
	$con=mysqli_connect($db_host, $db_user, $db_pass, $db_name);
?>